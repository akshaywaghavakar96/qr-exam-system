from flask import Flask, render_template, request, redirect, url_for, send_file, session
import openpyxl
import os
import random
import string
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
import qrcode

app = Flask(__name__)
app.secret_key = "your_secret_key_here"

# ─── CONFIG ─────────────────────────────────────────────────────
# Path to your Excel file on OneDrive (update this path!)
EXCEL_PATH = r"C:\Users\YourName\OneDrive\exam_database.xlsx"

# Your exam questions
EXAM_QUESTIONS = [
    {
        "question": "What is 2 + 2?",
        "options": ["3", "4", "5", "6"],
        "answer": "4"
    },
    {
        "question": "What is the capital of France?",
        "options": ["London", "Berlin", "Paris", "Rome"],
        "answer": "Paris"
    },
    {
        "question": "Which planet is closest to the sun?",
        "options": ["Earth", "Venus", "Mercury", "Mars"],
        "answer": "Mercury"
    },
    {
        "question": "What color is the sky?",
        "options": ["Green", "Red", "Blue", "Yellow"],
        "answer": "Blue"
    },
    {
        "question": "How many sides does a triangle have?",
        "options": ["2", "3", "4", "5"],
        "answer": "3"
    },
]

PASS_SCORE = 3  # Minimum correct answers to pass


# ─── EXCEL HELPERS ─────────────────────────────────────────────
def get_workbook():
    if not os.path.exists(EXCEL_PATH):
        wb = openpyxl.Workbook()

        # Sheet 1: Users
        ws1 = wb.active
        ws1.title = "Users"
        ws1.append(["Username", "Password", "Registered_At", "Status"])

        # Sheet 2: Results
        ws2 = wb.create_sheet("Results")
        ws2.append(["Username", "Score", "Total", "Passed", "Date", "Certificate"])

        wb.save(EXCEL_PATH)
    return openpyxl.load_workbook(EXCEL_PATH)


def save_workbook(wb):
    wb.save(EXCEL_PATH)


def find_user(username):
    wb = get_workbook()
    ws = wb["Users"]
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[0] == username:
            return {"username": row[0], "password": row[1], "status": row[3]}
    return None


def register_user(username, password):
    wb = get_workbook()
    ws = wb["Users"]
    ws.append([username, password, datetime.now().strftime("%Y-%m-%d %H:%M"), "registered"])
    save_workbook(wb)


def save_result(username, score, total, passed):
    wb = get_workbook()
    ws = wb["Results"]
    ws.append([
        username, score, total,
        "Yes" if passed else "No",
        datetime.now().strftime("%Y-%m-%d %H:%M"),
        "Yes" if passed else "No"
    ])
    save_workbook(wb)


def has_completed_exam(username):
    wb = get_workbook()
    ws = wb["Results"]
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[0] == username and row[3] == "Yes":
            return True, row[1]  # passed, score
    return False, 0


def generate_password():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))


# ─── ROUTES ────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["POST"])
def register():
    username = request.form.get("username", "").strip()
    if not username:
        return render_template("index.html", error="Please enter a username.")

    user = find_user(username)

    if user:
        # User exists → go to login
        return render_template("login.html", username=username, message="User found! Enter your password to start exam.")
    else:
        # New user → generate password
        password = generate_password()
        register_user(username, password)
        return render_template("show_password.html", username=username, password=password)


@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "").strip()

    user = find_user(username)

    if not user:
        return render_template("index.html", error="User not found. Please register first.")

    if user["password"] != password:
        return render_template("login.html", username=username, error="Wrong password! Try again.")

    # Check if already passed
    completed, score = has_completed_exam(username)
    if completed:
        session["username"] = username
        return render_template("certificate_ready.html", username=username, score=score)

    session["username"] = username
    return render_template("exam.html", questions=EXAM_QUESTIONS, username=username)


@app.route("/submit_exam", methods=["POST"])
def submit_exam():
    username = session.get("username")
    if not username:
        return redirect(url_for("index"))

    score = 0
    total = len(EXAM_QUESTIONS)
    results = []

    for i, q in enumerate(EXAM_QUESTIONS):
        user_answer = request.form.get(f"q{i}", "")
        correct = user_answer == q["answer"]
        if correct:
            score += 1
        results.append({
            "question": q["question"],
            "your_answer": user_answer,
            "correct_answer": q["answer"],
            "correct": correct
        })

    passed = score >= PASS_SCORE
    save_result(username, score, total, passed)

    return render_template("result.html", username=username, score=score,
                           total=total, passed=passed, results=results)


@app.route("/download_certificate/<username>")
def download_certificate(username):
    cert_path = f"/tmp/{username}_certificate.pdf"
    generate_certificate(username, cert_path)
    return send_file(cert_path, as_attachment=True,
                     download_name=f"{username}_certificate.pdf")


def generate_certificate(username, path):
    c = canvas.Canvas(path, pagesize=A4)
    width, height = A4

    # Background color
    c.setFillColorRGB(0.95, 0.97, 1.0)
    c.rect(0, 0, width, height, fill=True, stroke=False)

    # Border
    c.setStrokeColorRGB(0.2, 0.4, 0.8)
    c.setLineWidth(8)
    c.rect(20, 20, width - 40, height - 40, fill=False, stroke=True)

    c.setStrokeColorRGB(0.4, 0.6, 1.0)
    c.setLineWidth(2)
    c.rect(30, 30, width - 60, height - 60, fill=False, stroke=True)

    # Title
    c.setFillColorRGB(0.1, 0.2, 0.6)
    c.setFont("Helvetica-Bold", 40)
    c.drawCentredString(width / 2, height - 120, "CERTIFICATE")
    c.setFont("Helvetica-Bold", 24)
    c.drawCentredString(width / 2, height - 160, "OF COMPLETION")

    # Decorative line
    c.setStrokeColorRGB(0.8, 0.6, 0.1)
    c.setLineWidth(3)
    c.line(80, height - 180, width - 80, height - 180)

    # Body text
    c.setFillColorRGB(0.2, 0.2, 0.2)
    c.setFont("Helvetica", 18)
    c.drawCentredString(width / 2, height - 230, "This is to certify that")

    c.setFillColorRGB(0.1, 0.2, 0.6)
    c.setFont("Helvetica-Bold", 30)
    c.drawCentredString(width / 2, height - 275, username)

    c.setFillColorRGB(0.2, 0.2, 0.2)
    c.setFont("Helvetica", 18)
    c.drawCentredString(width / 2, height - 320, "has successfully completed the examination")

    c.setFont("Helvetica-Bold", 20)
    c.drawCentredString(width / 2, height - 360, "and passed with flying colors!")

    # Date
    c.setFont("Helvetica", 14)
    c.drawCentredString(width / 2, height - 430,
                        f"Date: {datetime.now().strftime('%B %d, %Y')}")

    # Bottom line
    c.setStrokeColorRGB(0.8, 0.6, 0.1)
    c.setLineWidth(3)
    c.line(80, 120, width - 80, 120)

    c.setFont("Helvetica-Oblique", 12)
    c.setFillColorRGB(0.4, 0.4, 0.4)
    c.drawCentredString(width / 2, 90, "Authorized Signature")

    c.save()


# ─── QR CODE GENERATOR ─────────────────────────────────────────
def generate_qr():
    url = "http://localhost:5000"  # Change to your server IP or domain
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img.save("exam_qr_code.png")
    print(f"✅ QR Code saved as 'exam_qr_code.png'")
    print(f"   Points to: {url}")


if __name__ == "__main__":
    generate_qr()
    print("🚀 Starting Exam Server at http://localhost:5000")
    app.run(debug=True, host="0.0.0.0", port=5000)
