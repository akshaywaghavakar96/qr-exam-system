# 📋 QR Code Exam System - Setup Guide

## 📁 Project Structure
```
exam_qr_system/
├── app.py                  ← Main Flask application
├── requirements.txt        ← Python packages
├── templates/
│   ├── index.html          ← Register/Login page
│   ├── show_password.html  ← Show generated password
│   ├── login.html          ← Password entry
│   ├── exam.html           ← Exam questions
│   ├── result.html         ← Exam result + certificate download
│   └── certificate_ready.html ← For returning users
└── exam_qr_code.png        ← Generated QR code (after running)
```

---

## ⚙️ Step 1 - Install Python Packages

Open Command Prompt and run:
```bash
pip install flask openpyxl reportlab qrcode[pil] pillow
```

---

## 📂 Step 2 - Set Your OneDrive Path

Open `app.py` and find this line (around line 15):
```python
EXCEL_PATH = r"C:\Users\YourName\OneDrive\exam_database.xlsx"
```
Change `YourName` to your actual Windows username.

**Example:**
```python
EXCEL_PATH = r"C:\Users\John\OneDrive\exam_database.xlsx"
```

---

## ❓ Step 3 - Add Your Exam Questions

In `app.py`, find `EXAM_QUESTIONS` and replace with your questions:
```python
EXAM_QUESTIONS = [
    {
        "question": "Your question here?",
        "options": ["Option A", "Option B", "Option C", "Option D"],
        "answer": "Option A"   # must match exactly
    },
    # add more...
]
```

---

## 🌐 Step 4 - Set Your Server URL for QR Code

If running on local network, find your IP:
```bash
ipconfig   # Windows
```
Look for IPv4 Address e.g. `192.168.1.5`

In `app.py` find:
```python
url = "http://localhost:5000"
```
Change to:
```python
url = "http://192.168.1.5:5000"   # your IP
```

---

## ▶️ Step 5 - Run the App

```bash
cd exam_qr_system
python app.py
```

This will:
- ✅ Create `exam_database.xlsx` in your OneDrive
- ✅ Generate `exam_qr_code.png` (your QR code!)
- ✅ Start the web server

---

## 📱 How Users Use It

| Step | Action |
|------|--------|
| 1 | Scan QR code with phone |
| 2 | Enter username → Get password shown on screen |
| 3 | Save the password! |
| 4 | Scan QR code again |
| 5 | Enter username + password → Start exam |
| 6 | Complete exam → Download PDF certificate |

---

## 📊 Excel Database (OneDrive)

The app auto-creates `exam_database.xlsx` with:

**Sheet 1: Users**
| Username | Password | Registered_At | Status |
|----------|----------|---------------|--------|

**Sheet 2: Results**
| Username | Score | Total | Passed | Date | Certificate |
|----------|-------|-------|--------|------|-------------|

---

## 🛠️ Customization

| What | Where in app.py |
|------|----------------|
| Pass score | `PASS_SCORE = 3` |
| Exam timer | In exam.html: `let time = 30 * 60` |
| Certificate design | `generate_certificate()` function |
| Questions | `EXAM_QUESTIONS` list |

---

## ⚠️ Common Issues

**Problem:** App can't find OneDrive file
**Fix:** Check the EXCEL_PATH in app.py

**Problem:** QR code doesn't open
**Fix:** Make sure phone and PC are on same WiFi network

**Problem:** Can't install packages
**Fix:** Run as Administrator or use: `pip install --user flask openpyxl reportlab qrcode pillow`
